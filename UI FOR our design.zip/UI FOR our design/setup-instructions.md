# AI Integration Setup Instructions

## Quick Setup (3 steps):

### 1. Replace Your n8n Domain
In `ai-integration.js`, replace `your-n8n-instance.com` with your actual n8n domain:
```javascript
this.n8nWebhookUrl = 'https://YOUR-N8N-DOMAIN.com/webhook/5f1d3203-6b48-4588-b3ef-c32ef8755698';
```

### 2. Import n8n Workflow
- Open your n8n instance
- Go to Workflows → Import from File
- Select `n8n-workflow.json`
- Activate the workflow

### 3. Test Integration
- Open `mine-dashboard.html`
- AI chat will auto-connect
- Try typing: "What's the system status?"

## Usage Examples:
- "Check maintenance needs"
- "Analyze pump efficiency" 
- "Predict system failures"
- "Optimize power switching"

The AI will respond with real-time analysis based on your SCADA data.