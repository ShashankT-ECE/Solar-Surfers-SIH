// AI Agent Integration for SCADA Dashboard
class AIAgentIntegration {
    constructor() {
        this.n8nWebhookUrl = 'http://localhost:5678/webhook/scada-ai';
        this.isConnected = false;
        this.conversationHistory = [];
    }

    async sendToAI(message, systemData = null) {
        const payload = {
            message: message,
            chatInput: message,
            sessionId: this.generateConversationId(),
            timestamp: new Date().toISOString(),
            systemData: systemData || this.getCurrentSystemData(),
            conversationId: this.generateConversationId()
        };

        try {
            console.log('Sending to n8n:', this.n8nWebhookUrl);
            console.log('Payload:', payload);
            
            const response = await fetch(this.n8nWebhookUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(payload)
            });
            
            console.log('Response status:', response.status);

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();
            console.log('n8n response:', result);
            this.isConnected = true;
            
            // Handle different response formats
            let aiResponse = result.response || result.output || result.text || result.message || result.data;
            
            // Check if result is an array
            if (Array.isArray(result) && result.length > 0) {
                aiResponse = result[0].response || result[0].output || result[0].text || result[0].message;
            }
            
            // If still no response, try to extract from nested objects
            if (!aiResponse) {
                console.log('Full response object:', result);
                aiResponse = JSON.stringify(result, null, 2);
            }
            
            // Add to conversation history
            this.conversationHistory.push({
                user: message,
                ai: aiResponse,
                timestamp: new Date().toISOString()
            });

            return { response: aiResponse };
        } catch (error) {
            console.error('AI Agent connection failed:', error);
            console.error('URL being called:', this.n8nWebhookUrl);
            this.isConnected = false;
            return { response: 'AI Agent temporarily unavailable. Please try again later.' };
        }
    }

    getCurrentSystemData() {
        // Get current dashboard data
        const dashboard = window.scadaDashboard || {};
        return {
            solar: dashboard.data?.solar || {},
            diesel: dashboard.data?.diesel || {},
            pump: dashboard.data?.pump || {},
            water: dashboard.data?.water || {},
            grid: dashboard.data?.grid || {},
            alerts: dashboard.alerts || [],
            currentMode: dashboard.data?.system?.current_mode || 'UNKNOWN'
        };
    }

    generateConversationId() {
        return `scada_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }

    // Predefined AI queries for quick access
    async getMaintenanceRecommendations() {
        return await this.sendToAI("What maintenance recommendations do you have based on current system status?");
    }

    async analyzeEfficiency() {
        return await this.sendToAI("Analyze current system efficiency and suggest optimizations.");
    }

    async predictFailures() {
        return await this.sendToAI("Based on current trends, predict potential system failures.");
    }

    async optimizePowerSwitching() {
        return await this.sendToAI("Recommend optimal power source switching strategy for the next 24 hours.");
    }
}

// Initialize AI integration
window.aiAgent = new AIAgentIntegration();