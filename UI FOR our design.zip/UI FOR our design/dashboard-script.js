// Dashboard Data and Real-time Updates
class MineDewateringDashboard {
    constructor() {
        this.currentView = 'operator';
        this.alerts = [
            {
                name: 'Low Solar Output',
                current_value: 32,
                threshold_value: 40,
                severity: 'critical',
                action: 'Switching to Grid',
                icon: '⚠️'
            },
            {
                name: 'Pump Efficiency Drop',
                current_value: 62,
                threshold_value: 65,
                severity: 'info',
                action: 'Schedule Maintenance',
                icon: '🔧'
            }
        ];
        
        this.switchHistory = [
            {
                timestamp: '12:21',
                previous_mode: 'Solar',
                new_mode: 'Grid',
                trigger_parameter: 'PV Power',
                trigger_value: 32,
                threshold: 40,
                explanation: 'PV dropped below 40% for 5 min (PV = 32%, Threshold = 40%)'
            }
        ];
        
        window.scadaDashboard = this;
        
        this.data = {
            solar: {
                pv_power_kw: 8.4,
                pump_load_kw: 10,
                solar_availability_pct: 84,
                dust_index_pct: 22,
                panel_temp_c: 47
            },
            grid: {
                voltage_v: 235,
                frequency_hz: 50.1,
                stability: "stable"
            },
            pump: {
                discharge_lpm: 420,
                efficiency_pct: 78,
                input_voltage_v: 230,
                current_a: 14,
                runtime_hours: 568
            },
            water: {
                sump_level_pct: 68
            },
            system: {
                current_mode: "SOLAR",
                auto_switch_reason: null,
                switch_timer_seconds: 420
            },
            cost: {
                cost_saved_inr: 960,
                co2_saved_kg: 32
            }
        };

        this.charts = {};
        this.init();
        this.startRealTimeUpdates();
    }

    init() {
        this.updateDisplay();
        this.initCharts();
        this.setupEventListeners();
        this.setupViewToggle();
        this.updateAlerts();
        this.updateSwitchReasons();
        this.updatePredictiveFeatures();
    }

    updateDisplay() {
        document.getElementById('currentMode').textContent = this.data.system.current_mode;
        document.getElementById('solarAvail').textContent = `${this.data.solar.solar_availability_pct}%`;
        document.getElementById('pumpState').textContent = this.data.pump.discharge_lpm > 0 ? 'ON' : 'OFF';
        document.getElementById('waterLevel').textContent = `${this.data.water.sump_level_pct}%`;

        document.getElementById('pvPower').textContent = this.data.solar.pv_power_kw.toFixed(1);
        document.getElementById('pumpLoad').textContent = this.data.solar.pump_load_kw.toFixed(1);
        
        const utilization = (this.data.solar.pv_power_kw / this.data.solar.pump_load_kw * 100);
        document.getElementById('solarUtilization').style.width = `${utilization}%`;
        document.querySelector('.bar-label').textContent = `${utilization.toFixed(0)}% Utilization`;

        const threshold = document.getElementById('solarThreshold');
        if (utilization >= 60) {
            threshold.className = 'threshold-indicator green';
            threshold.textContent = 'OPTIMAL';
        } else if (utilization >= 40) {
            threshold.className = 'threshold-indicator amber';
            threshold.textContent = 'CAUTION';
        } else {
            threshold.className = 'threshold-indicator red';
            threshold.textContent = 'CRITICAL';
        }

        document.getElementById('dustIndex').textContent = `${this.data.solar.dust_index_pct}%`;
        document.getElementById('powerLoss').textContent = `${Math.round(this.data.solar.dust_index_pct * 0.4)}%`;
        document.getElementById('panelTemp').textContent = `${this.data.solar.panel_temp_c}°C`;

        document.getElementById('gridVoltage').textContent = `${this.data.grid.voltage_v}V`;
        document.getElementById('gridFreq').textContent = `${this.data.grid.frequency_hz}Hz`;

        document.getElementById('pumpDischarge').textContent = this.data.pump.discharge_lpm;
        document.getElementById('pumpVoltage').textContent = `${this.data.pump.input_voltage_v}V`;
        document.getElementById('pumpCurrent').textContent = `${this.data.pump.current_a}A`;
        
        const efficiencyElement = document.querySelector('.percentage');
        if (efficiencyElement) {
            efficiencyElement.textContent = `${this.data.pump.efficiency_pct}%`;
        }

        document.getElementById('waterFill').style.height = `${this.data.water.sump_level_pct}%`;
        document.getElementById('currentWaterLevel').textContent = `${this.data.water.sump_level_pct}%`;

        document.getElementById('solarEnergy').textContent = `${this.data.solar.solar_availability_pct}%`;
        document.getElementById('co2Saved').textContent = `${this.data.cost.co2_saved_kg}kg`;
        document.querySelector('.savings-amount').textContent = `₹${this.data.cost.cost_saved_inr}`;

        const minutes = Math.floor(this.data.system.switch_timer_seconds / 60);
        const seconds = this.data.system.switch_timer_seconds % 60;
        document.getElementById('switchTimer').textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;

        document.getElementById('lastUpdate').textContent = `Last Update: ${new Date().toLocaleTimeString()}`;
    }

    initCharts() {
        this.drawStaticCharts();
    }
    
    drawStaticCharts() {
        const solarCanvas = document.getElementById('solarTrendChart');
        if (solarCanvas) {
            solarCanvas.width = 300;
            solarCanvas.height = 60;
            const solarCtx = solarCanvas.getContext('2d');
            solarCtx.strokeStyle = '#4ade80';
            solarCtx.lineWidth = 2;
            solarCtx.beginPath();
            solarCtx.moveTo(10, 40);
            solarCtx.lineTo(50, 35);
            solarCtx.lineTo(90, 20);
            solarCtx.lineTo(130, 18);
            solarCtx.lineTo(170, 22);
            solarCtx.lineTo(210, 24);
            solarCtx.lineTo(250, 26);
            solarCtx.stroke();
        }
        
        const savingsCanvas = document.getElementById('savingsChart');
        if (savingsCanvas) {
            savingsCanvas.width = 300;
            savingsCanvas.height = 60;
            const savingsCtx = savingsCanvas.getContext('2d');
            savingsCtx.fillStyle = 'rgba(74, 222, 128, 0.8)';
            const barWidth = 35;
            const bars = [35, 45, 30, 48, 55, 42, 48];
            bars.forEach((height, i) => {
                savingsCtx.fillRect(i * 40 + 10, 60 - height, barWidth, height);
            });
        }
        
        const dustCanvas = document.getElementById('dustLossChart');
        if (dustCanvas) {
            dustCanvas.width = 300;
            dustCanvas.height = 120;
            const dustCtx = dustCanvas.getContext('2d');
            dustCtx.strokeStyle = '#a855f7';
            dustCtx.lineWidth = 3;
            dustCtx.beginPath();
            dustCtx.moveTo(20, 110);
            dustCtx.lineTo(70, 105);
            dustCtx.lineTo(120, 95);
            dustCtx.lineTo(170, 75);
            dustCtx.lineTo(220, 50);
            dustCtx.lineTo(270, 25);
            dustCtx.stroke();
        }
    }

    setupViewToggle() {
        const viewButtons = document.querySelectorAll('.view-btn');
        viewButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                viewButtons.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                this.currentView = btn.dataset.view;
                this.updateViewVisibility();
            });
        });
    }

    updateViewVisibility() {
        const cards = document.querySelectorAll('.card');
        cards.forEach(card => {
            if (this.currentView === 'operator') {
                if (card.classList.contains('overview-card') || 
                    card.classList.contains('alerts-panel') ||
                    card.classList.contains('switch-reasons') ||
                    card.querySelector('#pumpDischarge') ||
                    card.querySelector('#waterFill') ||
                    card.querySelector('#pvPower') ||
                    card.querySelector('#gridVoltage')) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            } else if (this.currentView === 'maintenance') {
                if (card.classList.contains('predictive-loss') ||
                    card.querySelector('.maintenance-item') ||
                    card.querySelector('#dustIndex') ||
                    card.classList.contains('thresholds-panel')) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            } else if (this.currentView === 'management') {
                if (card.classList.contains('savings-card') ||
                    card.classList.contains('recovery-readiness') ||
                    card.querySelector('#co2Saved') ||
                    card.classList.contains('overview-card')) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            } else if (this.currentView === 'safety') {
                if (card.classList.contains('safety-view')) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            } else if (this.currentView === 'performance') {
                if (card.classList.contains('performance-view')) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            } else if (this.currentView === 'ai-assistance') {
                if (card.classList.contains('ai-assistant')) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            } else {
                card.style.display = 'none';
            }
        });
    }

    updateAlerts() {
        const alertsList = document.getElementById('alertsList');
        const alertCount = document.getElementById('alertCount');
        
        if (alertsList && alertCount) {
            alertCount.textContent = `${this.alerts.length} Active`;
            
            alertsList.innerHTML = this.alerts.map(alert => `
                <div class="alert-item ${alert.severity}">
                    <div class="alert-icon">${alert.icon}</div>
                    <div class="alert-content">
                        <div class="alert-title">${alert.name}</div>
                        <div class="alert-details">${alert.current_value}${typeof alert.current_value === 'number' ? '%' : ''}, Threshold = ${alert.threshold_value}${typeof alert.threshold_value === 'number' ? '%' : ''}</div>
                        <div class="alert-action">→ ${alert.action}</div>
                    </div>
                    <div class="alert-severity">${alert.severity.toUpperCase()}</div>
                </div>
            `).join('');
        }
    }

    updateSwitchReasons() {
        const switchTimeline = document.getElementById('switchTimeline');
        
        if (switchTimeline) {
            switchTimeline.innerHTML = this.switchHistory.map(switch_item => `
                <div class="switch-item">
                    <div class="switch-time">${switch_item.timestamp}</div>
                    <div class="switch-flow">
                        <span class="mode-from">${switch_item.previous_mode}</span>
                        <span class="arrow">→</span>
                        <span class="mode-to">${switch_item.new_mode}</span>
                    </div>
                    <div class="switch-reason">${switch_item.explanation}</div>
                </div>
            `).join('');
        }
    }

    updatePredictiveFeatures() {
        const currentDustEl = document.getElementById('currentDust');
        const predictedLossEl = document.getElementById('predictedLoss');
        const cleaningDaysEl = document.getElementById('cleaningDays');
        const readinessScoreEl = document.getElementById('readinessScore');
        const readinessCircleEl = document.getElementById('readinessCircle');
        
        if (currentDustEl) currentDustEl.textContent = `${this.data.solar.dust_index_pct}%`;
        if (predictedLossEl) predictedLossEl.textContent = `${(this.data.solar.dust_index_pct * 0.4).toFixed(1)}%`;
        
        const cleaningThreshold = 30;
        const currentDust = this.data.solar.dust_index_pct;
        const dailyIncrease = 2;
        const daysToClean = Math.max(1, Math.ceil((cleaningThreshold - currentDust) / dailyIncrease));
        if (cleaningDaysEl) cleaningDaysEl.textContent = `${daysToClean} days`;
        
        const pvRecovered = this.data.solar.solar_availability_pct > 60;
        const gridStable = this.data.grid.voltage_v >= 207 && this.data.grid.voltage_v <= 253;
        const noOverride = true;
        
        const readinessFactors = [pvRecovered, gridStable, noOverride];
        const readinessScore = Math.round((readinessFactors.filter(f => f).length / readinessFactors.length) * 100);
        
        if (readinessScoreEl) readinessScoreEl.textContent = `${readinessScore}%`;
        if (readinessCircleEl) readinessCircleEl.style.setProperty('--percentage', readinessScore);
        
        const factors = document.querySelectorAll('.factor');
        if (factors.length >= 3) {
            factors[0].className = `factor ${pvRecovered ? 'good' : 'warning'}`;
            factors[0].querySelector('.status').textContent = pvRecovered ? '✓' : '⚠';
            
            factors[1].className = `factor ${gridStable ? 'good' : 'warning'}`;
            factors[1].querySelector('.status').textContent = gridStable ? '✓' : '⚠';
            
            factors[2].className = `factor ${noOverride ? 'good' : 'warning'}`;
            factors[2].querySelector('.status').textContent = noOverride ? '✓' : '⚠';
        }
    }

    setupEventListeners() {
        const themeToggle = document.getElementById('themeToggle');
        if (themeToggle) {
            themeToggle.addEventListener('change', () => {
                document.body.classList.toggle('dark', themeToggle.checked);
                const label = document.querySelector('.theme-label');
                if (label) label.textContent = themeToggle.checked ? '☀️' : '🌙';
            });
        }

        const aiInput = document.getElementById('aiInput');
        const aiSend = document.getElementById('aiSendBtn');

        if (aiSend && aiInput) {
            aiSend.addEventListener('click', () => {
                if (aiInput.value.trim()) {
                    this.handleAIQuery(aiInput.value);
                    aiInput.value = '';
                }
            });
        }

        if (aiInput) {
            aiInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter' && aiInput.value.trim()) {
                    this.handleAIQuery(aiInput.value);
                    aiInput.value = '';
                }
            });
        }

        document.querySelectorAll('.suggestion').forEach(suggestion => {
            suggestion.addEventListener('click', () => {
                this.handleAIQuery(suggestion.textContent);
            });
        });

        const generateSummaryBtn = document.getElementById('generateSummaryBtn');
        if (generateSummaryBtn) {
            generateSummaryBtn.addEventListener('click', () => {
                this.generateFullReport();
            });
        }

        document.querySelectorAll('.safety-tab').forEach(tab => {
            tab.addEventListener('click', (e) => {
                document.querySelectorAll('.safety-tab').forEach(t => t.classList.remove('active'));
                document.querySelectorAll('.safety-panel').forEach(p => p.classList.remove('active'));
                e.target.classList.add('active');
                document.querySelector(`.safety-panel[data-panel="${e.target.dataset.tab}"]`).classList.add('active');
            });
        });

        document.querySelectorAll('.perf-tab').forEach(tab => {
            tab.addEventListener('click', (e) => {
                document.querySelectorAll('.perf-tab').forEach(t => t.classList.remove('active'));
                document.querySelectorAll('.perf-panel').forEach(p => p.classList.remove('active'));
                e.target.classList.add('active');
                document.querySelector(`.perf-panel[data-panel="${e.target.dataset.tab}"]`).classList.add('active');
            });
        });
    }

    async handleAIQuery(query) {
        const aiMessages = document.getElementById('aiMessages');
        if (!aiMessages) return;

        const userMsg = document.createElement('div');
        userMsg.className = 'ai-chat-message user';
        userMsg.innerHTML = `<div class="message-content">${query}</div>`;
        aiMessages.appendChild(userMsg);
        aiMessages.scrollTop = aiMessages.scrollHeight;

        const typingMsg = document.createElement('div');
        typingMsg.className = 'ai-chat-message bot typing';
        typingMsg.innerHTML = `<div class="message-content">Analyzing...</div>`;
        aiMessages.appendChild(typingMsg);
        aiMessages.scrollTop = aiMessages.scrollHeight;

        try {
            if (!window.aiAgent) {
                throw new Error('AI Agent not initialized');
            }

            const result = await window.aiAgent.sendToAI(query, this.data);
            
            typingMsg.remove();
            
            const botMsg = document.createElement('div');
            botMsg.className = 'ai-chat-message bot';
            botMsg.innerHTML = `<div class="message-content">${result.response}</div>`;
            aiMessages.appendChild(botMsg);
            aiMessages.scrollTop = aiMessages.scrollHeight;
        } catch (error) {
            console.error('AI query failed:', error);
            typingMsg.remove();
            
            const errorMsg = document.createElement('div');
            errorMsg.className = 'ai-chat-message bot error';
            errorMsg.innerHTML = `<div class="message-content">⚠️ N8N Connection Error<br><small>Check console. Is N8N running on localhost:5678?</small></div>`;
            aiMessages.appendChild(errorMsg);
            aiMessages.scrollTop = aiMessages.scrollHeight;
        }
    }

    generateFullReport() {
        const recEl = document.getElementById('aiRecommendations');
        if (!recEl) return;

        recEl.innerHTML = '<div style="text-align:center;padding:20px;color:#667eea;">Generating comprehensive report...</div>';
        
        setTimeout(() => {
            const report = `
                <div class="recommendation-item">
                    <span class="icon">📊</span>
                    <div class="rec-content">
                        <strong>System Performance: 85% Optimal</strong>
                        <p>Solar at ${this.data.solar.solar_availability_pct}%, Grid stable at ${this.data.grid.voltage_v}V, Pump efficiency ${this.data.pump.efficiency_pct}%</p>
                    </div>
                </div>
                <div class="recommendation-item">
                    <span class="icon">🧹</span>
                    <div class="rec-content">
                        <strong>IMMEDIATE: Panel Cleaning Required</strong>
                        <p>Dust at ${this.data.solar.dust_index_pct}% causing ${Math.round(this.data.solar.dust_index_pct * 0.4)}% power loss. Clean within 3 days to restore efficiency.</p>
                    </div>
                </div>
                <div class="recommendation-item">
                    <span class="icon">🔧</span>
                    <div class="rec-content">
                        <strong>SHORT-TERM: Monitor Pump Trends</strong>
                        <p>Current efficiency ${this.data.pump.efficiency_pct}% is acceptable but trending down. Schedule inspection in 2 weeks.</p>
                    </div>
                </div>
                <div class="recommendation-item">
                    <span class="icon">💰</span>
                    <div class="rec-content">
                        <strong>Cost Optimization Opportunity</strong>
                        <p>Current savings: ₹${this.data.cost.cost_saved_inr}/day. Panel cleaning could increase savings by 8-10%.</p>
                    </div>
                </div>
                <div class="recommendation-item">
                    <span class="icon">🎯</span>
                    <div class="rec-content">
                        <strong>LONG-TERM: Automated Cleaning System</strong>
                        <p>Consider installing automated panel cleaning to maintain 90%+ efficiency year-round.</p>
                    </div>
                </div>
            `;
            recEl.innerHTML = report;
        }, 1500);
    }

    updateAISensorReadings() {
        const sensorPV = document.getElementById('sensorPV');
        const sensorGrid = document.getElementById('sensorGrid');
        const sensorPump = document.getElementById('sensorPump');
        const sensorWater = document.getElementById('sensorWater');
        const sensorDust = document.getElementById('sensorDust');
        const sensorTemp = document.getElementById('sensorTemp');

        if (sensorPV) {
            const pvVariation = (Math.random() - 0.5) * 0.2;
            const newPV = (this.data.solar.pv_power_kw + pvVariation).toFixed(1);
            sensorPV.textContent = `${newPV} kW`;
        }

        if (sensorGrid) {
            const gridVariation = (Math.random() - 0.5) * 2;
            const newGrid = Math.round(this.data.grid.voltage_v + gridVariation);
            sensorGrid.textContent = `${newGrid} V`;
        }

        if (sensorPump) {
            const pumpVariation = (Math.random() - 0.5) * 1;
            const newPump = Math.round(this.data.pump.efficiency_pct + pumpVariation);
            sensorPump.textContent = `${newPump}%`;
        }

        if (sensorWater) sensorWater.textContent = `${this.data.water.sump_level_pct}%`;
        if (sensorDust) sensorDust.textContent = `${this.data.solar.dust_index_pct}%`;

        if (sensorTemp) {
            const tempVariation = (Math.random() - 0.5) * 2;
            const newTemp = Math.round(this.data.solar.panel_temp_c + tempVariation);
            sensorTemp.textContent = `${newTemp}°C`;
        }
    }

    startRealTimeUpdates() {
        setInterval(() => {
            document.getElementById('lastUpdate').textContent = `Last Update: ${new Date().toLocaleTimeString()}`;
        }, 5000);

        setInterval(() => {
            this.updateAISensorReadings();
        }, 3000);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new MineDewateringDashboard();
});

document.addEventListener('DOMContentLoaded', () => {
    const cards = document.querySelectorAll('.card');
    cards.forEach(card => {
        card.addEventListener('mouseenter', () => {
            card.style.transform = 'translateY(-4px)';
        });
        
        card.addEventListener('mouseleave', () => {
            card.style.transform = 'translateY(0)';
        });
    });

    const suggestions = document.querySelectorAll('.suggestion');
    suggestions.forEach(suggestion => {
        suggestion.addEventListener('click', () => {
            suggestion.style.transform = 'scale(0.98)';
            setTimeout(() => {
                suggestion.style.transform = 'scale(1)';
            }, 150);
        });
    });
});
