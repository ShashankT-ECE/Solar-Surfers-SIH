// AI Chat Integration for Dashboard
function initAIChat() {
    const aiInput = document.getElementById('aiInput');
    const aiSendBtn = document.getElementById('aiSendBtn');
    const aiMessages = document.getElementById('aiMessages');
    
    if (!aiInput || !aiSendBtn || !aiMessages) return;

    // Send message function
    async function sendMessage() {
        const message = aiInput.value.trim();
        if (!message) return;

        // Add user message
        addMessage(message, 'user');
        aiInput.value = '';

        // Show typing indicator
        showTyping();

        try {
            const response = await window.aiAgent.sendToAI(message);
            hideTyping();
            addMessage(response.response || 'No response received', 'ai');
            updateConnectionStatus(true);
        } catch (error) {
            hideTyping();
            updateConnectionStatus(false);
        }
    }

    // Event listeners
    aiSendBtn.addEventListener('click', sendMessage);
    aiInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') sendMessage();
    });

    // Add message to chat
    function addMessage(text, type) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `ai-message ${type}`;
        
        const icon = type === 'user' ? '👤' : type === 'ai' ? '🤖' : '⚠️';
        messageDiv.innerHTML = `
            <span class="message-icon">${icon}</span>
            <span class="message-text">${text}</span>
            <span class="message-time">${new Date().toLocaleTimeString()}</span>
        `;
        
        aiMessages.appendChild(messageDiv);
        aiMessages.scrollTop = aiMessages.scrollHeight;
    }

    function showTyping() {
        const typingDiv = document.createElement('div');
        typingDiv.className = 'ai-message typing';
        typingDiv.id = 'typingIndicator';
        typingDiv.innerHTML = `
            <span class="message-icon">🤖</span>
            <span class="message-text">AI is thinking...</span>
        `;
        aiMessages.appendChild(typingDiv);
        aiMessages.scrollTop = aiMessages.scrollHeight;
    }

    function hideTyping() {
        const typing = document.getElementById('typingIndicator');
        if (typing) typing.remove();
    }

    function updateConnectionStatus(connected) {
        const statusIcon = document.getElementById('aiStatusIcon');
        const statusText = document.getElementById('aiStatusText');
        
        if (connected) {
            statusIcon.style.color = '#4ade80';
            statusText.textContent = 'AI Agent Connected';
        } else {
            statusIcon.style.color = '#ef4444';
            statusText.textContent = 'AI Agent Disconnected';
        }
    }


}

// Quick AI actions
async function askAI(type) {
    const actions = {
        maintenance: () => window.aiAgent.getMaintenanceRecommendations(),
        efficiency: () => window.aiAgent.analyzeEfficiency(),
        predict: () => window.aiAgent.predictFailures(),
        optimize: () => window.aiAgent.optimizePowerSwitching()
    };

    if (actions[type]) {
        const response = await actions[type]();
        const aiMessages = document.getElementById('aiMessages');
        if (aiMessages) {
            const messageDiv = document.createElement('div');
            messageDiv.className = 'ai-message ai';
            messageDiv.innerHTML = `
                <span class="message-icon">🤖</span>
                <span class="message-text">${response.response}</span>
                <span class="message-time">${new Date().toLocaleTimeString()}</span>
            `;
            aiMessages.appendChild(messageDiv);
            aiMessages.scrollTop = aiMessages.scrollHeight;
        }
    }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', initAIChat);